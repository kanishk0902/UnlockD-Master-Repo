import React, { useState } from 'react';
import { useFinance } from '../context/FinanceContext';
import { formatCurrency } from '../utils/money';

export function BillSplitter() {
  const { state, createGroup, addGroupExpense, markSettled } = useFinance();
  
  // Group Creation State
  const [groupName, setGroupName] = useState('');
  
  // Expense State
  const [desc, setDesc] = useState('');
  const [amountInput, setAmountInput] = useState('');
  const [paidById, setPaidById] = useState(state.accounts[0]?.id || '');

  const handleCreateGroup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupName.trim()) return;
    // Auto-add the first 3 accounts (e.g. Kanishk, Ritvik, Rohit) to the group
    const memberIds = state.accounts.slice(0, 3).map(a => a.id);
    createGroup(groupName, memberIds);
    setGroupName('');
  };

  const handleAddExpense = (e: React.FormEvent, groupId: string, members: string[]) => {
    e.preventDefault();
    const amount = parseFloat(amountInput);
    if (isNaN(amount) || amount <= 0 || !desc.trim() || !paidById) return;

    // Auto-calculate an EQUAL split among all members for the demo
    const splitAmount = amount / members.length;
    const splits = members.map(memberId => ({
      memberId,
      amount: splitAmount
    }));

    addGroupExpense(groupId, desc, amount, paidById, splits);
    setDesc('');
    setAmountInput('');
  };

  return (
    <div style={{ backgroundColor: '#111827', border: '1px solid #1e293b', padding: '24px', borderRadius: '12px', marginBottom: '24px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <h3 style={{ margin: '0', fontSize: '18px', fontWeight: 'bold' }}>Group Bill Splitting</h3>
      </div>

      {state.groups.length === 0 ? (
        <form onSubmit={handleCreateGroup} style={{ display: 'flex', gap: '12px' }}>
          <input 
            type="text" 
            placeholder="New Group Name (e.g. Goa Trip)" 
            value={groupName}
            onChange={(e) => setGroupName(e.target.value)}
            style={{ flex: 1, padding: '10px', borderRadius: '6px', backgroundColor: '#0b0f19', border: '1px solid #334155', color: 'white' }}
          />
          <button type="submit" style={{ padding: '10px 16px', borderRadius: '6px', backgroundColor: '#3b82f6', color: 'white', border: 'none', cursor: 'pointer', fontWeight: 'bold' }}>
            Create Group
          </button>
        </form>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
          {state.groups.map(group => (
            <div key={group.id} style={{ border: '1px solid #334155', borderRadius: '8px', padding: '16px', backgroundColor: '#0f172a' }}>
              <h4 style={{ margin: '0 0 16px 0', color: '#f8fafc', fontSize: '16px' }}>{group.name}</h4>
              
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
                
                {/* LEFT COLUMN: Add Expense Form */}
                <div>
                  <h5 style={{ margin: '0 0 12px 0', color: '#94a3b8', fontSize: '12px', textTransform: 'uppercase' }}>Add Group Expense</h5>
                  <form onSubmit={(e) => handleAddExpense(e, group.id, group.members)} style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                    <input 
                      type="text" 
                      placeholder="What was it for? (e.g. Dinner)" 
                      value={desc}
                      onChange={(e) => setDesc(e.target.value)}
                      style={{ padding: '10px', borderRadius: '6px', backgroundColor: '#0b0f19', border: '1px solid #334155', color: 'white' }}
                    />
                    <div style={{ display: 'flex', gap: '12px' }}>
                      <input 
                        type="number" 
                        placeholder="Amount (₹)" 
                        value={amountInput}
                        onChange={(e) => setAmountInput(e.target.value)}
                        style={{ flex: 1, padding: '10px', borderRadius: '6px', backgroundColor: '#0b0f19', border: '1px solid #334155', color: 'white' }}
                      />
                      <select 
                        value={paidById}
                        onChange={(e) => setPaidById(e.target.value)}
                        style={{ flex: 1, padding: '10px', borderRadius: '6px', backgroundColor: '#0b0f19', border: '1px solid #334155', color: 'white' }}
                      >
                        {group.members.map(memberId => {
                          const acc = state.accounts.find(a => a.id === memberId);
                          return <option key={memberId} value={memberId}>{acc?.name || memberId}</option>;
                        })}
                      </select>
                    </div>
                    <button type="submit" style={{ padding: '10px', borderRadius: '6px', backgroundColor: '#10b981', color: '#0b0f19', border: 'none', cursor: 'pointer', fontWeight: 'bold' }}>
                      Split Equally
                    </button>
                  </form>
                </div>

                {/* RIGHT COLUMN: Optimized Settlements */}
                <div>
                  <h5 style={{ margin: '0 0 12px 0', color: '#94a3b8', fontSize: '12px', textTransform: 'uppercase' }}>Optimized Settlements</h5>
                  {group.settlements.length === 0 ? (
                    <p style={{ color: '#64748b', fontSize: '13px', margin: 0 }}>Everyone is settled up!</p>
                  ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                      {group.settlements.map(settlement => {
                        const fromAcc = state.accounts.find(a => a.id === settlement.fromId);
                        const toAcc = state.accounts.find(a => a.id === settlement.toId);
                        const isCompleted = settlement.status === 'COMPLETED';

                        return (
                          <div key={settlement.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#0b0f19', padding: '12px', borderRadius: '6px', border: `1px solid ${isCompleted ? '#10b981' : '#334155'}` }}>
                            <div style={{ fontSize: '13px', color: isCompleted ? '#64748b' : '#f8fafc', textDecoration: isCompleted ? 'line-through' : 'none' }}>
                              <strong>{fromAcc?.name}</strong> owes <strong>{toAcc?.name}</strong>
                              <div style={{ color: isCompleted ? '#10b981' : '#ef4444', fontWeight: 'bold', marginTop: '4px' }}>
                                {formatCurrency(settlement.amount)}
                              </div>
                            </div>
                            {!isCompleted && (
                              <button 
                                onClick={() => markSettled(group.id, settlement.id)}
                                style={{ padding: '6px 12px', borderRadius: '4px', backgroundColor: '#3b82f6', color: 'white', border: 'none', cursor: 'pointer', fontSize: '12px', fontWeight: 'bold' }}
                              >
                                Settle
                              </button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}