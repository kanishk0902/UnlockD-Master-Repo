import React, { createContext, useContext, useEffect, useReducer } from 'react';
import type { Account, AuditEvent, AuditLevel, FinanceState, Transaction, TransferRequest, SplitGroup, GroupExpense, Settlement } from '../types';
import { seedAccounts } from '../data/seed';
import { generateId } from '../utils/id';
import { formatCurrency } from '../utils/money';

const MAX_AUDIT_EVENTS = 200;
const STORAGE_KEY = 'unlockd_finance_state_v1';
const DUPLICATE_WINDOW_MS = 5000;

type Action =
  | { type: 'TRANSFER_FUNDS'; payload: TransferRequest }
  | { type: 'UPDATE_BUDGET'; payload: { category: string; amount: number } }
  | { type: 'RESET_BUDGETS' }
  | { type: 'ADD_BUDGET'; payload: { category: string; limit: number } }
  | { type: 'DELETE_BUDGET'; payload: { id: string } }
  | { type: 'CREATE_GROUP'; payload: { name: string; members: string[] } }
  | { type: 'ADD_GROUP_EXPENSE'; payload: { groupId: string; description: string; amount: number; paidById: string; splits: { memberId: string; amount: number }[] } }
  | { type: 'MARK_SETTLED'; payload: { groupId: string; settlementId: string } }
  | { type: 'RESET' };

function loadInitialState(): FinanceState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as FinanceState;
      if (parsed.accounts?.length) {
        return {
          ...parsed,
          groups: parsed.groups || [],
        };
      }
    }
  } catch {}
  return {
    accounts: seedAccounts,
    transactions: [],
    processedRequestIds: [],
    auditEvents: [],
    budgets: [],
    groups: [],
  };
}

function optimizeSettlements(groupId: string, expenses: GroupExpense[]): Settlement[] {
  const balances: Record<string, number> = {};

  expenses.forEach(exp => {
    balances[exp.paidById] = (balances[exp.paidById] || 0) + exp.amount;
    exp.splits.forEach(split => {
  balances[split.memberId] =
    (balances[split.memberId] || 0) - split.amount;
});
  });

  const debtors = Object.keys(balances).filter(id => balances[id] <= -0.01).map(id => ({ id, amount: Math.abs(balances[id]) })).sort((a, b) => b.amount - a.amount);
  const creditors = Object.keys(balances).filter(id => balances[id] >= 0.01).map(id => ({ id, amount: balances[id] })).sort((a, b) => b.amount - a.amount);

  const settlements: Settlement[] = [];
  let i = 0, j = 0;

  while (i < debtors.length && j < creditors.length) {
    const debtor = debtors[i];
    const creditor = creditors[j];
    const amount = Math.min(debtor.amount, creditor.amount);

    settlements.push({
      id: generateId('stl'),
      groupId,
      fromId: debtor.id,
      toId: creditor.id,
      amount,
      status: 'PENDING'
    });

    debtor.amount -= amount;
    creditor.amount -= amount;

    if (debtor.amount < 0.01) i++;
    if (creditor.amount < 0.01) j++;
  }
  return settlements;
}

function financeReducer(state: FinanceState, action: Action): FinanceState {
  switch (action.type) {
    case 'RESET':
      return { accounts: seedAccounts, transactions: [], processedRequestIds: [], auditEvents: [], budgets: [], groups: [] };

    case 'ADD_BUDGET':
      return { ...state, budgets: [...state.budgets, { id: generateId('bgt'), category: action.payload.category, limit: action.payload.limit, spent: 0, lastResetDate: new Date().toISOString() }] };

    case 'DELETE_BUDGET':
      return { ...state, budgets: state.budgets.filter(b => b.id !== action.payload.id) };

    case 'UPDATE_BUDGET':
      return { ...state, budgets: state.budgets.map(b => b.category === action.payload.category ? { ...b, spent: b.spent + action.payload.amount } : b) };

    case 'RESET_BUDGETS':
      return { ...state, budgets: state.budgets.map(b => ({ ...b, spent: 0, lastResetDate: new Date().toISOString() })) };

    case 'CREATE_GROUP': {
      return { 
        ...state, 
        groups: [...state.groups, { 
          id: generateId('grp'), 
          name: action.payload.name, 
          members: action.payload.members,
          expenses: [], 
          settlements: [] 
        }] 
      };
    }

    case 'ADD_GROUP_EXPENSE': {
      const { groupId, description, amount, paidById, splits } = action.payload;

      

      const newExpense: GroupExpense = {
        id: generateId('exp'),
        groupId,
        description,
        amount,
        paidById,
        date: new Date().toISOString(),
        splitType: 'CUSTOM',
        splits
      };

      const updatedGroups = state.groups.map(g => {
        if (g.id !== groupId) return g;
        const updatedExpenses = [...g.expenses, newExpense];
        const optimizedSettlements = optimizeSettlements(groupId, updatedExpenses);
        return { ...g, expenses: updatedExpenses, settlements: optimizedSettlements };
      });

      return { ...state, groups: updatedGroups };
    }

    case 'MARK_SETTLED': {
      const { groupId, settlementId } = action.payload;
      const updatedGroups = state.groups.map(g => {
        if (g.id !== groupId) return g;
        const updatedSettlements = g.settlements.map(s => s.id === settlementId ? { ...s, status: 'COMPLETED' as const } : s);
        return { ...g, settlements: updatedSettlements };
      });
      return { ...state, groups: updatedGroups };
    }

    case 'TRANSFER_FUNDS': {
      const { requestId, fromAccountId, toAccountId, amount, note, requestHash, category } = action.payload;
      const timestamp = new Date().toISOString();
      if (state.processedRequestIds.includes(requestId)) return state;

      const fromAccount = state.accounts.find((a) => a.id === fromAccountId);
      const toAccount = state.accounts.find((a) => a.id === toAccountId);

      if (!fromAccount || !toAccount || fromAccountId === toAccountId || amount <= 0 || fromAccount.balance < amount) return state;

      const nextAccounts: Account[] = state.accounts.map((acc) => {
        if (acc.id === fromAccountId) return { ...acc, balance: acc.balance - amount };
        if (acc.id === toAccountId) return { ...acc, balance: acc.balance + amount };
        return acc;
      });

      const nextBudgets = state.budgets.map(b => 
        (category && category.toLowerCase() === b.category.toLowerCase()) ? { ...b, spent: b.spent + amount } : b
      );

      return {
        ...state,
        accounts: nextAccounts,
        transactions: [
          { id: generateId('txn'), requestId, fromAccountId, toAccountId, amount, status: 'completed', timestamp, note, category, balanceAfterFrom: nextAccounts.find(a=>a.id===fromAccountId)!.balance, balanceAfterTo: nextAccounts.find(a=>a.id===toAccountId)!.balance },
          ...state.transactions,
        ],
        processedRequestIds: [...state.processedRequestIds, requestId],
        budgets: nextBudgets,
      };
    }

    default:
      return state;
  }
}

interface FinanceContextValue {
  state: FinanceState;
  transfer: (req: TransferRequest) => void;
  reset: () => void;
  updateBudget: (category: string, amount: number) => void;
  resetBudgets: () => void;
  addBudget: (category: string, limit: number) => void;
  deleteBudget: (id: string) => void;
  createGroup: (name: string, members: string[]) => void;
  addGroupExpense: (groupId: string, description: string, amount: number, paidById: string, splits: { memberId: string; amount: number }[]) => void;
  markSettled: (groupId: string, settlementId: string) => void;
}

const FinanceContext = createContext<FinanceContextValue | undefined>(undefined);

export function FinanceProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(financeReducer, undefined, loadInitialState);

  useEffect(() => { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }, [state]);

  const transfer = (req: TransferRequest) => dispatch({ type: 'TRANSFER_FUNDS', payload: req });
  const reset = () => dispatch({ type: 'RESET' });
  const updateBudget = (cat: string, amt: number) => dispatch({ type: 'UPDATE_BUDGET', payload: { category: cat, amount: amt } });
  const resetBudgets = () => dispatch({ type: 'RESET_BUDGETS' });
  const addBudget = (cat: string, limit: number) => dispatch({ type: 'ADD_BUDGET', payload: { category: cat, limit } });
  const deleteBudget = (id: string) => dispatch({ type: 'DELETE_BUDGET', payload: { id } });
  const createGroup = (name: string, members: string[]) => dispatch({ type: 'CREATE_GROUP', payload: { name, members } });
  const addGroupExpense = (groupId: string, description: string, amount: number, paidById: string, splits: { memberId: string; amount: number }[]) => dispatch({ type: 'ADD_GROUP_EXPENSE', payload: { groupId, description, amount, paidById, splits } });
  const markSettled = (groupId: string, settlementId: string) => dispatch({ type: 'MARK_SETTLED', payload: { groupId, settlementId } });

  return (
    <FinanceContext.Provider value={{ state, transfer, reset, updateBudget, resetBudgets, addBudget, deleteBudget, createGroup, addGroupExpense, markSettled }}>
      {children}
    </FinanceContext.Provider>
  );
}

export function useFinance(): FinanceContextValue {
  const ctx = useContext(FinanceContext);
  if (!ctx) throw new Error('useFinance must be used within a FinanceProvider');
  return ctx;
}