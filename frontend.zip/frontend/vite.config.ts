import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    port: 5173,
    strictPort: true,
    watch: {
      usePolling: true, // needed for hot-reload inside Docker on some hosts
    },
  },
  preview: {
    host: '0.0.0.0',
    port: 5173,
  },
})